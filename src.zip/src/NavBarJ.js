import React from 'react';
import{Link} from "react-router-dom";

function NavBarJ(){
    return(
        <ul>
             <li>
        <Link to="/Proj">Clique Aqui pra entrar no formulario de Projeto</Link>
        </li>
        </ul>
    
    );
    
}

export default NavBarJ;